function main() {
  console.log("Hello, World!");
}

main();
